# Calculator.Py
Basic Calculator with simple GUI.
I made it simple so that you can add and put some changes on it.
